let req = new XMLHttpRequest();

req.onreadystatechange = () => {
  if (req.readyState == XMLHttpRequest.DONE) {
    console.log(req.responseText);
  }
};

req.open("POST", "https://api.jsonbin.io/v3/b", true);
req.setRequestHeader("Content-Type", "application/json");
req.setRequestHeader("X-Master-Key", "<$2b$10$gc1XrHiX.tAZ1UFmdz9zI.YLPY9pR07TEQoz6LWHPuKe2nwJkkXXy
>");
req.send('{"sample": "Hello World"}');